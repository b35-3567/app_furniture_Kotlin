package com.example.lab2.ASM1.model



data class RegisterRequest(val email: String, val password: String, val fullname: String)
data class RegisterResponse(val message: String)
