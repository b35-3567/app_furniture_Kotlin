package com.example.lab2.Demo_Function

// Hàm để in danh sách các loại thực phẩm từ một danh sách
fun Foodlist1(fruitList: List<String>) {
    print("Tên của thực phẩm trong danh sách:")
    for (fruit in fruitList) {
        print("$fruit;")
    }
}

// Hàm để in danh sách các loại thực phẩm từ một mảng
fun foodArray1(productArray: Array<String>) {
    println("");
    println("có ${productArray.size} trong mảng");
    print("Tên của thực phẩm trong mảng:");
    for (product in productArray) {
            print("$product;")
    }

}
//ha,f chuyển đổi chuỗi thành số
//fun convertToIntArray(stringArray:Array<String>):IntArray{
//  return  555;
//}



// Hàm main để chạy các ví dụ
fun main() {
    // Ví dụ sử dụng hàm Foodlist
    val fruits = listOf("Apple", "Banana", "Cherry")
    Foodlist1(fruits)

    // Ví dụ sử dụng hàm foodArray
    val products = arrayOf("Milk", "Bread", "Cheese")
    foodArray1(products)

   var danhSach=List(10){
       "danh"+"tt"
   }
    println("Danh Sách");
    danhSach.forEachIndexed{index, item ->
        println("$index:$item")
    }

}
