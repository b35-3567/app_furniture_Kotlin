package com.example.lab2

fun main(){
    print("nhập số n:");
    var n= readln().toInt();
    for (i in 1..10) {
        if (i == 5) {
            break // Dừng vòng lặp ngay khi i == 5
        }
        println(i)
    }
    println("================================================");
    for (i in 1..5) {
        if (i == 3) {
            continue // Bỏ qua giá trị i = 3 và tiếp tục vòng lặp
        }
        println(i)
    }
    println("================================================");
    myLabel@ for (i in 1..3) {
        println("Outer loop: $i");
        for (j in 1..3) {
            println("Inner loop: $j");
            if (j == 2) {
                break@myLabel // Kết thúc vòng lặp ngoài cùng khi gặp j == 2
            } else {
                continue@myLabel // Tiếp tục vòng lặp ngoài cùng khi j != 2
            }
        }
    }

}