package com.example.lab2

fun main() {
    print("Nhập số a: ")
    val a = readLine()!!.toInt()
    print("Nhập số b: ")
    val b = readLine()!!.toInt()

    var tempA = a
    var tempB = b
    var isBContainedInA = true

    var prevDigitA = -1 // Lưu trữ chữ số trước đó của a

    while (tempB > 0) {
        val digitB = tempB % 10
        var isDigitBInA = false

        // Duyệt qua từng chữ số của a
        while (tempA > 0) {
            val digitA = tempA % 10

            // Kiểm tra xem chữ số của b có trong a không
            if (digitA == digitB) {
                // Kiểm tra xem chữ số của a có liền trước chữ số trước đó không
                if (prevDigitA != -1 && digitA != prevDigitA - 1) {
                    isBContainedInA = false
                    break
                }
                isDigitBInA = true
                prevDigitA = digitA
                break
            }
            tempA /= 10
        }

        if (!isDigitBInA) {
            isBContainedInA = false
            break
        }

        tempB /= 10
    }

    if (isBContainedInA) {
        println("$b chứa trong $a")
    } else {
        println("$b không chứa trong $a")
    }
}
