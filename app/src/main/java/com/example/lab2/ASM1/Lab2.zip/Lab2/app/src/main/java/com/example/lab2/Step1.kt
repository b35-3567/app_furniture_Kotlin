@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3Api::class)

package com.example.lab2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Email
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lab2.ui.theme.Lab2Theme

class Step1Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Lab2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    Step1Screen()
                }
            }
        }
    }
}

@Composable
fun Step1Screen() {
    Column(
        modifier = Modifier
            .background(color = Color(0xFFFFFFFF))
            .fillMaxHeight()
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
    ) {
        Text(
            text = "Delivery of \n products",
            fontSize = 49.sp,
            fontStyle = FontStyle.Normal,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF45BC1B),
            lineHeight = 39.sp,
            modifier = Modifier
                .padding(top = 77.dp)
                .align(alignment = Alignment.CenterHorizontally),
            textAlign = TextAlign.Center,
        )
        Text(text = "Authorization or registration",
            fontSize = 20.sp,
            fontStyle = FontStyle.Normal,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1A1A1A),
            modifier = Modifier
                .padding(top =37.dp, start = 20.dp, end = 20.dp)
                .align(alignment = Alignment.CenterHorizontally),
            textAlign = TextAlign.Center)
        OutlinedTextField(
            value = "",
            onValueChange = {},
            label = { Text(text = "Enter phone number",
                fontSize = 16.sp,
                color = Color(0xFFB5E4A4)
            )},
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .padding(top = 22.dp)
                .width(420.dp)
                .height(66.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            leadingIcon = {
                Text(
                    text = "+7",
                    color = Color.Black,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(8.dp)
                )
            },
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color(0xFFB5E4A4),
                unfocusedBorderColor = Color(0xFFB5E4A4)
            )
        )
        Button(
            onClick = { /* TODO: Xử lý sự kiện khi nút được nhấn */ },
            modifier = Modifier
                .padding(top = 24.dp)
                .width(420.dp)
                .height(63.dp)
                .padding(horizontal = 25.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8FD776)),


        ) {
            Text(text = "Confirm Login",
                fontSize = 16.sp,
                fontStyle = FontStyle.Normal) // Chữ của nút
        }
Text(text = "By clicking on the \"Confirm Login\" button, I agree to the  terms of use of the service"
,
    modifier = Modifier
        .padding(top = 32.dp)
        .width(440.dp)
        .height(54.dp)
        .padding(horizontal = 33.dp),
)
    }

}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun Step1Preview() {
    Lab2Theme {
        Step1Screen()
    }
}
