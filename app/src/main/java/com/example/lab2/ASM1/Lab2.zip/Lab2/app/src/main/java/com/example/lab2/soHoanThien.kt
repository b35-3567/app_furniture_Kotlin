package com.example.lab2

fun main(){
do{
    print("nhập vào số để kiểm tra đó là số hoàn thiện n:");
    var n= readln().toInt();
    var tong=0;
    for(i in 1 until n){
        if(n%i==0){
            tong+=i;
        }
    }

    if(tong==n){
        println("số ${n} là số hoàn thiện");

    }else{
        println("số ${n} không phải là số hoàn thiện")
    }
}while (n>0)

}