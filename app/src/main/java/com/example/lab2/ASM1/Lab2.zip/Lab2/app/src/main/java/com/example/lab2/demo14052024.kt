package com.example.lab2

fun main() {
    print("Nhập vào số a: ")
    var a = readLine()!!.toInt()
    print("Nhập vào số b: ")
    var b = readLine()!!.toInt()

    var bienB = b
    var bienA = a
    var isBContainedInA = false
    var prevDigitA = -1 // Lưu trữ chữ số trước đó của a
    while (bienB > 0) {
        var digitB = bienB % 10

        while (bienA > 0) {
            var digitA = bienA % 10
            if (digitA == digitB) {
                // Kiểm tra xem chữ số của a có liền trước chữ số trước đó không
                if(digitA==prevDigitA-1){
                    println(prevDigitA)
                    isBContainedInA=true;
                    break;
                }
                prevDigitA=digitA;
                break;
            }
        }
        bienA /= 10
        bienB /= 10
    }
    if (isBContainedInA) {
        println("Số $b có các chữ số liên tiếp trong số $a")
    } else {
        println("Số $b không có các chữ số liên tiếp trong số $a")
    }
}
