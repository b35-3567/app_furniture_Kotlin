package com.example.lab2

import kotlin.math.pow

fun main (){
  do {
      print("nhập vào bài cần test x: từ 1 đến 8:");
      var x= readln().toInt();
      when (x){
          1->{
              print("nhập vào số nguyên n:");
              val n= readln().toInt();
              println("các số từ 1 đến n");
              for(i in 1..n){
                  print(""+i);
              }
              println();
          }
          2-> {
              print("nhập vào số nguyên n:");
              val n= readln().toInt();
              println("số chắn từ 1 đến n");
              for(i in 1..n){
                  if(i%2==0){
                      print(""+i+";");
                  }
              }
              println();
          }
          3->{
              print("nhập vào số nguyên n:");
              val n= readln().toInt();
              println("số lẻ khoogn chia hết cho 3 từ 1 đến n");
              for(i in 1..n){
                  if(i%2!=0 && i%3!=0){
                      print(""+i+";");
                  }
              }
              println();
          }
          4->{
              println("tính biểu thức S1=1+2+3...+n");
              print("nhập vào số nguyên n:");
              val n= readln().toInt();
              println("tính biểu thức S1=1+2+3...+${n}");
              var kq:Int =0;
              for (i in 1..n){
                  kq+=i;
              }
              println("kết quả của phép tính:S1=1+2+3...+${n}=${kq}")
          }
          5->{
              println("tính biểu thức S1=-1+2-3...+((-1)mũ n)n");
              print("nhập vào số nguyên n:");
              val n= readln().toInt();
              print("tính biểu thức S1= ");
              var s1 = 0 // Khởi tạo biến tổng s1
              for(i in 1..n){
                  val term = (-1.0).pow(i) * i // Tính giá trị của từng số hạng
                  print(""+term + ";");
                  s1+=term.toInt();
              }
              println("");
              println("giá trị biểu thức:"+s1)
          }
          6->{
              println("tính biểu thức S1=1/2+2/3+3/4...+n/(n+1)");
              print("nhập vào số nguyên n:");
              val n= readln().toInt();
              print("tính biểu thức S1= ");
              var s1=0.0;
              for(i in 1..n){
                  print("${i}/${i+1}+");
                  s1+=i.toDouble()/(i+1);

              }
              println("");
              println("giá trị biểu thức:"+s1);
          }
          7->{
              println("tính biểu thức  X mũ n");
              print("nhập vào số thực x:");
              val x= readln().toDouble();
              print("nhập vào số thực n:");
              val n= readln().toInt();
              println("giá trị biểu thức:${x.pow(n)}");

          }
8->{
    println("tính tổng các chữ số:");
    print("nhập số n:");
    var n= readln().toInt();
    // Chuyển số thành chuỗi
    var numberString=n.toString();
    var tong=0
    for(char in numberString){
        tong+=char.toString().toInt();

    }
    println("tổng của ${n}=${tong}")
}
          else->{

              println();
          }
      }
  }while (x>=1 &&x<=8 )
}


