package com.example.lab2

fun main() {
    print("Nhập vào số a: ")
    var a = readLine()!!.toInt()
    print("Nhập vào số b: ")
    var b = readLine()!!.toInt()

    var bienB = b
    var bienA = a
    var isBContainedInA = false
    var prevDigitA = -1 // Lưu trữ chữ số trước đó của a

    while (bienB > 0) {
        var digitB = bienB % 10

        while (bienA > 0) {
            var digitA = bienA % 10

            if (digitA == digitB) {
                // Kiểm tra xem chữ số của a có liền trước chữ số trước đó không
                if (prevDigitA != -1 && digitA != prevDigitA - 1) {
                    isBContainedInA = false
                    break
                }

                isBContainedInA = true // Cập nhật biến kiểm tra

                prevDigitA = digitA // Cập nhật chữ số trước đó của a
                break
            }

            bienA /= 10
        }

        if (!isBContainedInA) {
            break
        }

        bienB /= 10
    }

    if (isBContainedInA) {
        println("Số $b có các chữ số liên tiếp trong số $a")
    } else {
        println("Số $b không có các chữ số liên tiếp trong số $a")
    }
}
