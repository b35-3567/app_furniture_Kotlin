@file:OptIn(ExperimentalMaterial3Api::class)


package com.example.lab2.thi

import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.lab2.ASM1.DMSPScreen
import com.example.lab2.ASM1.LoginScreen
import com.example.lab2.ASM1.viewmodel.CategoryViewModel
import com.example.lab2.R
import com.example.lab2.ui.theme.Lab2Theme

@OptIn(ExperimentalMaterial3Api::class)
class LoginThiActivity : ComponentActivity() {

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            Lab2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    val navController = rememberNavController()
                    LoginThiScreen(navController)
                }
            }
        }
    }

}
@ExperimentalMaterial3Api
@Composable
 fun  LoginThiScreen(navController: NavController){
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context= LocalContext.current;
    fun signIn(){

        if(username.isNotEmpty()&&password.isNotEmpty()){
            if(password.length>=8){
                navController.navigate("home")
            }
            Toast.makeText(context,"password phả đầy đủ 8 ký tự",Toast.LENGTH_SHORT).show();
        }else{

            Toast.makeText(context,"nhập đầy đủ thông tin ở 2 ô",Toast.LENGTH_SHORT).show();
        }
    }
Column {
    Row (
        modifier = Modifier
            .width(375.dp)
            .height(55.dp),
        verticalAlignment = Alignment.CenterVertically
    ){
        Box(modifier = Modifier
            .padding(start = 20.dp)
            .size(24.dp)) {
            androidx.compose.material.Icon(
                imageVector = Icons.Default.ArrowBackIosNew,
                contentDescription = "Search Icon"
            )
        }
    }
Text(
    text = "Welcome back to \n" +
            "Mega Mall",
    modifier = Modifier
        .padding(top = 116.dp, start = 25.dp),
    fontWeight = FontWeight(700),
    fontSize = 25.sp,
    color = Color(0xFF0C1A30)
)
    Text(
        text = "Silahkan masukan data untuk login",
        modifier = Modifier
            .padding(top = 20.dp, start = 25.dp),
        fontWeight = FontWeight(400),
        fontSize = 14.sp,
        color = Color(0xFF838589)
    )

        androidx.compose.material3.Text(
            text = "Email",
            modifier = Modifier
                .padding(top = 55.dp, start = 25.dp),
            color = Color.Black,
            fontStyle = FontStyle.Normal,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )

        TextField(value = username,
            onValueChange = {username=it.uppercase()},
            modifier = Modifier
                .padding(start = 20.dp)
                .width(350.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent
            ),
            placeholder = { Text(text = "Nhập email/username")}

        )
        androidx.compose.material3.Text(
            text = "Password",
            modifier = Modifier
                .padding(top = 55.dp, start = 25.dp),
            color = Color.Black,
            fontStyle = FontStyle.Normal,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )

        TextField(value = password,
            onValueChange = {password=it},
            modifier = Modifier
                .padding(start = 20.dp)
                .width(350.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent
            ),
            trailingIcon = {
                // modifier = Modifier.padding(end = 8.dp) )
                Image(painterResource(id = R.drawable.img_1), contentDescription = "",
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .size(20.dp))
            },
            keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
            placeholder = { Text("Masukan Alamat Email/ No Telepon Anda") }, // Sử dụng Text composable
            visualTransformation = PasswordVisualTransformation() // Chuyển đổi văn bản thành dấu *
        )

        Button(onClick = {signIn()},
            modifier = Modifier
                .padding(top = 44.dp, start = 0.dp)
                .width(325.dp)
                .align(Alignment.CenterHorizontally)
                .height(50.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = Color(0xFF3669C9),
                contentColor = Color.White
            )

        ) {
            androidx.compose.material3.Text(text = "Sign in")
        }
Spacer(modifier = Modifier
    .weight(1.0f))
Row(modifier = Modifier
    .padding(start = 25.dp, end = 25.dp)
    .fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,

   ) {
       Text(text = "Forgot Password")
       Text(text = "Sign Up")

}

}
}



@RequiresApi(Build.VERSION_CODES.R)
@Preview(showSystemUi = true, showBackground = true)
@Composable
 fun LoginThiPreview() {
    Lab2Theme {
        val navController = rememberNavController()
         LoginThiScreen(navController)
    }
}
