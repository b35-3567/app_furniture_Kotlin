@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.lab2.thi

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.lab2.ui.theme.Lab2Theme
import com.google.accompanist.insets.ProvideWindowInsets
import com.google.accompanist.systemuicontroller.rememberSystemUiController

class loginDe1Activity : ComponentActivity() {

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
      enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(Color.Yellow.toArgb()))
        setContent {
            Lab2Theme {
                // A surface container using the 'background' color from the theme
                ProvideWindowInsets {
                    val systemUiController = rememberSystemUiController()
                    SideEffect {
                        systemUiController.setSystemBarsColor(
                            color = Color.Transparent,
                            darkIcons = false
                        )
                    }

                }
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    val navController = rememberNavController()
                    loginDe1Screen(navController);
                }
            }
        }
    }
}
@Composable
fun loginDe1Screen(navController: NavController){
    Column(
        modifier = Modifier
            .background(color = Color(0xFF33907C))
            .fillMaxSize()

    ) {
        Box(modifier = Modifier
            .padding(start = 20.dp)
            .size(24.dp)) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Search Icon",
                tint = Color.White
            )
        }
        androidx.compose.material3.Text(
            text = "Welcome to tradly",
            fontSize = 24.sp,
            fontWeight = FontWeight(700),
            modifier = Modifier
                .padding(top = 155.dp, )
                .align(CenterHorizontally),
            color = Color.White
        )
        androidx.compose.material3.Text(
            text = "Signup to your account",
            fontSize = 16.sp,
            modifier = Modifier
                .padding(top = 63.dp, )
                .align(CenterHorizontally),
            color = Color.White
        )
        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier
                .padding(start = 40.dp,top=15.dp )
                .width(311.dp)
                .height(48.dp)
                .background(Color.Transparent)
                .border(1.dp, Color(0xFFFFFFFF), shape = RoundedCornerShape(20.dp)),
            textStyle = TextStyle(color = Color.Black),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
            colors = TextFieldDefaults.outlinedTextFieldColors(
                cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                focusedBorderColor = Color.Transparent, // Màu viền khi focus
                unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

            ),
            placeholder = { Text("First Name",
                color = Color.White
            ) }, // Sử dụng Text composable
        )
        /////
        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier
                .padding(start = 40.dp,top=15.dp )
                .width(311.dp)
                .height(48.dp)
                .background(Color.Transparent)
                .border(1.dp, Color(0xFFFFFFFF), shape = RoundedCornerShape(20.dp)),
            textStyle = TextStyle(color = Color.Black),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
            colors = TextFieldDefaults.outlinedTextFieldColors(
                cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                focusedBorderColor = Color.Transparent, // Màu viền khi focus
                unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

            ),
            placeholder = { Text("Last Name",
                color = Color.White
            ) }, // Sử dụng Text composable
        )
        /////////////////////////////////////
        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier
                .padding(start = 40.dp,top=15.dp )
                .width(311.dp)
                .height(48.dp)
                .background(Color.Transparent)
                .border(1.dp, Color(0xFFFFFFFF), shape = RoundedCornerShape(20.dp)),
            textStyle = TextStyle(color = Color.Black),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
            colors = TextFieldDefaults.outlinedTextFieldColors(
                cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                focusedBorderColor = Color.Transparent, // Màu viền khi focus
                unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

            ),
            placeholder = { Text("Email ID/Phone Number",
                color = Color.White
            ) }, // Sử dụng Text composable
        )
        ///////////////////////////////
        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier
                .padding(start = 40.dp,top=15.dp )
                .width(311.dp)
                .height(48.dp)
                .background(Color.Transparent)
                .border(1.dp, Color(0xFFFFFFFF), shape = RoundedCornerShape(20.dp)),
            textStyle = TextStyle(color = Color.Black),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
            colors = TextFieldDefaults.outlinedTextFieldColors(
                cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                focusedBorderColor = Color.Transparent, // Màu viền khi focus
                unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

            ),
            placeholder = { Text("Password",
                color = Color.White
            ) }, // Sử dụng Text composable
        )
        ///////////////////////////////////////////
        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier
                .padding(start = 40.dp,top=15.dp )
                .width(311.dp)
                .height(48.dp)
                .background(Color.Transparent)
                .border(1.dp, Color(0xFFFFFFFF), shape = RoundedCornerShape(20.dp)),
            textStyle = TextStyle(color = Color.Black),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
            colors = TextFieldDefaults.outlinedTextFieldColors(
                cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                focusedBorderColor = Color.Transparent, // Màu viền khi focus
                unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

            ),
            placeholder = { Text("Re-enter Password",
                color = Color.White
            ) }, // Sử dụng Text composable
        )
        ////////////////////////////////////
        Button(onClick = {},
            modifier = Modifier
                .padding(top = 20.dp, start = 40.dp)
                .width(311.dp)
                //.align(CenterHorizontally)
                .height(48.dp),
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = Color(0xFFFFFFFF),
                contentColor = Color(0xFF13B58C)
            )

        ) {
            androidx.compose.material3.Text(text = "Sign in")
        }
        /////

    }
}
@RequiresApi(Build.VERSION_CODES.R)
@Preview(showSystemUi = true, showBackground = true)
@Composable
fun loginDe1Preview() {
    Lab2Theme {
        val navController = rememberNavController()
        loginDe1Screen(navController)
    }
}