package com.example.lab2

fun main(){
 do {
     print("nhập vào số n để in ra dãy số fibonacci:");
     var n= readln().toInt();
     var   a=1;
     var   b=1;
     var count=1
     while (count<=n){
         print("${a};");
         var next=a+b;
         a=b;
         b=next;
         count += 1  // Tăng bộ đếm
     }
     println();
 }while (n>0)

}