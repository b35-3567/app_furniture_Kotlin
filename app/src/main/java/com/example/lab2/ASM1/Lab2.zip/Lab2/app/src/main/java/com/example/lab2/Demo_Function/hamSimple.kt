package com.example.lab2.Demo_Function

fun sayHello(){
    println("helllo các bạn yêu ơi")
}

fun main(){
  sayHello()
}