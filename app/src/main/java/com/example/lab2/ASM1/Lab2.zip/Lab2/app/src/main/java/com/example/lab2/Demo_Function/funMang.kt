package com.example.lab2.Demo_Function


import com.example.lab2.R

fun Foodlist(fruitList:List<String>){
    for (fruit in fruitList){
        println("Tên của thực phẩm trong danh sách:${fruit}")
    }
}
fun foodArray(prodcutArray:Array<String>){
    for (product in prodcutArray){
        println("Tên của thực phẩm trong mảng:${product}")
    }

}
//fun getItemsForCategory(category: String): List<Product> {
//    // Replace these with your own drawable resource IDs
//    val imageResId = R.drawable.img_1
//
//    return when (category) {
//        "Chair" -> List(10) { Product("Chair Item $it", (50 + it).toDouble(), imageResId) }
//        "Bed" -> List(10) { Product("Bed Item $it", (150 + it).toDouble(), imageResId) }
//        "Sofar" -> List(10) { Product("Sofar Item $it", (200 + it).toDouble(), imageResId) }
//        "Lamp" -> List(10) { Product("Lamp Item $it", (30 + it).toDouble(), imageResId) }
//        "Balo" -> List(10) { Product("Balo Item $it", (40 + it).toDouble(), imageResId) }
//        else -> List(10) { Product("Popular Item $it", (100 + it).toDouble(), imageResId) }
//    }
//}
fun main(){
    //val thucpham= Foodlist(listOf(""))
    val fruits= listOf("Apple","Organe","Yam","Mango","Grapes");
    Foodlist(fruits)
    //dùng list of không thể thêm được vì nó cố định
    //dùng arrayListOf có thể thay đổi được
    val traiCay= arrayListOf("Apple","Grapes","Yam","mango");
    traiCay.add("Chanh")
    println(traiCay);
    println("mảng trong trai cay array list of vị trí 1 :${traiCay[1]}");
    traiCay[1]="Duarian";
    println(traiCay.joinToString())



    val products= arrayOf("Meat","Fish","Cow","sheep");
    foodArray(products);
    println("mảng trong products  array of vị trí 1 :${products[1]}");
    products[1]="Chicken";
    println(products.joinToString())
}