@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3Api::class)

package com.example.lab2

import android.graphics.drawable.Icon
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lab2.ui.theme.Lab2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Lab2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                )
                {
                    Greeting("Android")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
/*
fun GreetingPreview() {
    Lab2Theme {
        Greeting("Android")
    }
}

 */
fun Main(){
  Column(
      modifier = Modifier
          .background(color = Color(0xFFF0000))
          //0xF = #
          .fillMaxHeight()
          .fillMaxWidth()
          //.fillMaxWidth(0.75f)
  ) {
      Text(text = "Hello\n các bạn",
          fontSize = 30.sp,
          fontStyle = FontStyle.Italic,
          fontWeight = FontWeight.Bold,
          modifier = Modifier
              .padding(30.dp)
              .align(alignment = Alignment.CenterHorizontally)
              .background(color = Color.Blue)
              .padding(30.dp),
          textAlign = TextAlign.Center

      );
      Text(text = "Xin Chào")

      TextField(value = "",
          onValueChange = {},
          modifier = Modifier.fillMaxWidth(),
          placeholder = {
              Text(text = "nhập nha")
          },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          leadingIcon = { androidx.compose.material3.Icon(imageVector = Icons.Default.AccountBox, contentDescription = "")}
      )

      OutlinedTextField(value = "", onValueChange ={},
          label = { Text(text = "nhập nha")},
          shape = RoundedCornerShape(20.dp)
      )
      Button(onClick = { /*TODO*/ },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(Color.Green)

      ) {
          Text(text = "Đăng ký")
      }
      OutlinedButton(onClick = { /*TODO*/ }) {
          Text(text = "Đăng ký ngoài")
      }
      Image(painterResource(id =R.drawable.lequyen ) , contentDescription = "")
  }

}
