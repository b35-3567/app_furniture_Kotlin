package com.example.lab2.thi

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.lab2.R
import com.example.lab2.ui.theme.Lab2Theme
import kotlin.reflect.KProperty

class HomeThiActivity : ComponentActivity() {

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            Lab2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    val navController = rememberNavController()
                    HomeThiScreen(navController)
                }
            }
        }
    }
}
data class ProductTech(val Hinh:Int)
@Composable
fun HomeThiScreen(navController: NavController){
  var data by remember {
        mutableStateOf(
            listOf(
                ProductTech(Hinh=R.drawable.tainghe),
                ProductTech(Hinh=R.drawable.tainghe1),
                ProductTech(Hinh=R.drawable.tainghe1),
                ProductTech(Hinh=R.drawable.tainghe),
                ProductTech(Hinh=R.drawable.tainghe1) ,
                ProductTech(Hinh=R.drawable.tainghe)
            )

        )
  }

        Column(
            modifier = Modifier
             .fillMaxSize()
//                    .padding(16.dp)
            //  .verticalScroll(rememberScrollState())
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .padding(end = 25.dp)
                    .fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .padding(start = 20.dp)
                        .size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBackIosNew,
                        contentDescription = "Search Icon"
                    )
                }
                Text(text = "Category")
                Box(
                    modifier = Modifier
                        .padding(start = 20.dp)
                        .size(24.dp)
                ) {
                    androidx.compose.material.Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Search Icon",
                    )
                    Canvas(
                        modifier = Modifier
                            .size(9.dp)
                            .align(Alignment.TopEnd)
                            .padding(top = 2.dp, end = 2.dp)
                    ) { drawCircle(Color.Red) }
                }
            }
            Text(
                text = "Gadget",
                fontSize = 24.sp,
                fontWeight = FontWeight(700),
                modifier = Modifier
                    .padding(top = 30.dp, start = 25.dp)
            )
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .padding(start = 45.dp, top = 12.dp)
                    .width(325.dp)
                    .height(50.dp)
                    .background(color = Color(0xDC4C5C4))
            ) {
                Text(
                    text = "Search Product Name",
                    color = Color(0xFFC4C5C4)
                )
                Box(
                    modifier = Modifier
                        .padding(start = 20.dp)
                        .size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search Icon"
                    )
                }
            }
           Box(
                modifier = Modifier
                //   .verticalScroll(rememberScrollState())
            ) {
                //thẻ hiển sản phẩm theo 2 cột 3 hàng
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(50.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    items(data) { product ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                        ) {
                            Column(
                                modifier = Modifier
                                    .width(156.dp)
                                    .height(242.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = product.Hinh),
                                    contentDescription = "",
                                    modifier = Modifier
                                        .size(130.dp)
                                )
                                Text(text = "TMA-2 HD Wireless")
                                Text(text = "Rp. 1.500.000")
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Image(
                                        painter = painterResource(id = R.drawable.stara),
                                        contentDescription = "",
                                        modifier = Modifier
                                            .size(10.dp)
                                    )
                                    Text(text = "4.6", modifier = Modifier.padding(start = 2.dp))
                                    Text(
                                        text = "86 Reviews",
                                        modifier = Modifier.padding(start = 5.dp)
                                    )
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .padding(start = 10.dp)
                                    ) {

                                        Canvas(
                                            modifier = Modifier
                                                .size(5.dp)
                                        ) { drawCircle(Color(0xFF000000)) }
                                        Canvas(
                                            modifier = Modifier
                                                .size(5.dp)
                                        ) { drawCircle(Color(0xFF000000)) }
                                        Canvas(
                                            modifier = Modifier
                                                .size(5.dp)
                                        ) { drawCircle(Color(0xFF000000)) }
                                    }
                                }
                            }

                        }

                    }

                }
Box( modifier = Modifier
    .padding(top = 650.dp)
    .width(331.dp)
    .height(100.dp)
    .border(2.dp, color = Color.Black, RoundedCornerShape(15.dp))
    .align(alignment = Alignment.Center)
) {
    Text(text = "ggggggggggg", modifier = Modifier
        .align(alignment = Alignment.Center)
    )
}

            }//Column






        }


}




@RequiresApi(Build.VERSION_CODES.R)
@Preview(showSystemUi = true, showBackground = true)
@Composable
fun HomeThiPreview() {
    Lab2Theme {
        val navController = rememberNavController()
        HomeThiScreen(navController)
    }
}

