package com.example.lab2

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.lab2.ui.theme.Lab2Theme

class duDoanActivity : ComponentActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set decor fits system windows to false
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            Lab2Theme {
                HideSystemBars()
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    duDoanScreen()
                }
            }
        }
    }
}

@Composable
fun HideSystemBars() {
    val context = LocalContext.current

    DisposableEffect(Unit) {
        val window = context.findActivity()?.window ?: return@DisposableEffect onDispose {}
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)

        insetsController.apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        onDispose {
            insetsController.apply {
                show(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
            }
        }
    }
}

fun Context.findActivity(): Activity? {
    var context = this
    while (context is ContextWrapper) {
        if (context is Activity) return context
        context = context.baseContext
    }
    return null
}

@Composable
fun duDoanScreen() {
    var soA by remember { mutableStateOf((Math.random() * 10).toInt() + 1) }
    var soB by remember { mutableStateOf((Math.random() * 10).toInt() + 1) }
    var soC by remember { mutableStateOf((Math.random() * 10).toInt() + 1) }
    var kq by remember { mutableStateOf("") }

    fun duDoanDung() {
        if (soA + soB == soC) {
            kq = "Đúng"
        } else {
            kq = ""
        }
    }

    fun duDoanSai() {
        if (soA + soB != soC) {
            kq = "Sai"
            soA = (Math.random() * 10).toInt() + 1
            soB = (Math.random() * 10).toInt() + 1
            soC = (Math.random() * 10).toInt() + 1
        } else {
            kq = ""
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row {
            Text(text = "$soA")
            Text(text = "+ $soB")
        }
        Text(text = "=")
        Text(text = "$soC")

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { duDoanDung() }) {
            Text("Đúng")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { duDoanSai() }) {
            Text("Sai")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = kq,
            modifier = Modifier
                .fillMaxWidth()
                .background(color = Color.Gray),
            color = Color.White,
            fontSize = 34.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Preview(showSystemUi = true, showBackground = true)
@Composable
fun duDoanPreview() {
    Lab2Theme {
        duDoanScreen()
    }
}
