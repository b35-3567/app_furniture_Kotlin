package com.example.lab2.ASM1.model

data class LoginRequest(val email: String, val password: String)
data class LoginResponse(val message: String)
