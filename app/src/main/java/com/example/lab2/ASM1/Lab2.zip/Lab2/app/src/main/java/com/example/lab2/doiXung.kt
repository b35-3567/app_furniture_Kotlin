package com.example.lab2

fun reverseNumber(number: Int):Int{
    var n=number;
    var reverseNumber =0;
    while (n!=0){
        val digit=n%10;
        reverseNumber= reverseNumber *10+digit;
        n /=10;
    }
    return reverseNumber;
}
fun main(){
   var originNumber=321;

    println("tính tổng các chữ số:");
    print("nhập số n:");
    var n= readln().toInt();
    // Chuyển số thành chuỗi
    var numberString=n.toString();
var numberLength=numberString.length;
 var halfLength=numberLength/2;
    var firstNumber=numberString.substring(0,halfLength);
    var secondNumber=numberString.substring(halfLength);
    println("phần đầu của số :${firstNumber}");
    println("phần sau của số :${secondNumber}");
    println("số ban đầu:"+originNumber);
    var reversedNumber= reverseNumber(secondNumber.toInt());
    println("số đảo ngược:"+reversedNumber);

   if(firstNumber.toInt()==reversedNumber){
       println(" số này  là số đối xứng");
   }else{
       println(" số này không phải  là số đối xứng");
   }
}