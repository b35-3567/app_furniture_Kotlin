@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3Api::class)

package com.example.lab2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lab2.ui.theme.Lab2Theme

class Step2Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Lab2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    Step2Screen()
                }
            }
        }
    }
}

@Composable
fun Step2Screen() {
    Column(
        modifier = Modifier
            .background(color = Color(0xFFFFFFFF))
            .fillMaxHeight()
            .fillMaxWidth()
            .padding(horizontal = 20.dp) // Đặt padding một lần cho Column để tránh lặp lại
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_back_green),
            contentDescription = "",

        )
        Text(
            text = "Delivery of \n products",
            fontSize = 49.sp,
            fontStyle = FontStyle.Normal,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF45BC1B),
            lineHeight = 39.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 20.dp)
                .align(alignment = Alignment.CenterHorizontally)
        )
        Text(
            text = "Enter code from SMS",
            fontSize = 20.sp,
            fontStyle = FontStyle.Normal,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 10.dp)
                .align(alignment = Alignment.CenterHorizontally)
        )
        Text(
            text = buildAnnotatedString {
                append("We have sent a message to\n phone")
                withStyle(style = SpanStyle(fontWeight = FontWeight.Bold,
                    color = Color.Black
                )) {
                    append("+7 0964333")
                }

                append("")
            },
            fontSize = 16.sp,
            fontStyle = FontStyle.Normal,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF6B6D7B),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 8.dp)
                .align(alignment = Alignment.CenterHorizontally)
        )
        Row(
            modifier = Modifier
                .padding(start = 31.dp, end = 32.dp,top=20.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            OutlinedTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier
                    .size(64.dp) // Kích thước mỗi ô vuông
                    .background(Color.White, shape = RoundedCornerShape(8.dp))
                    .border(3.dp, Color(0xFFDAF2D1), shape = RoundedCornerShape(8.dp)),
                textStyle = TextStyle(color = Color.Black),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                    focusedBorderColor = Color.Transparent, // Màu viền khi focus
                    unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

                )
            )


            OutlinedTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier
                    .size(64.dp) // Kích thước mỗi ô vuông
                    .background(Color.White, shape = RoundedCornerShape(8.dp))
                    .border(3.dp, Color(0xFFDAF2D1), shape = RoundedCornerShape(8.dp)),
                textStyle = TextStyle(color = Color.Black),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                        cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                            focusedBorderColor = Color.Transparent,  // Màu viền khi focus
                unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

            )
            )

            OutlinedTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier
                    .size(64.dp) // Kích thước mỗi ô vuông
                    .background(Color.White, shape = RoundedCornerShape(8.dp))
                    .border(3.dp, Color(0xFFDAF2D1), shape = RoundedCornerShape(8.dp)),
                textStyle = TextStyle(color = Color.Black),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                    focusedBorderColor = Color.Transparent, // Màu viền khi focus
                    unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

                )
            )
            OutlinedTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier
                    .size(64.dp) // Kích thước mỗi ô vuông
                    .background(Color.White, shape = RoundedCornerShape(8.dp))
                    .border(3.dp, Color(0xFFDAF2D1), shape = RoundedCornerShape(8.dp)),
                textStyle = TextStyle(color = Color.Black),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                keyboardActions = KeyboardActions.Default, // optional, để xác định hành động khi nhấn enter
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    cursorColor = Color.Transparent, // Màu của con trỏ nhập văn bản
                    focusedBorderColor = Color.Transparent,  // Màu viền khi focus
                    unfocusedBorderColor = Color.Transparent, // Màu viền khi không focus

                )
            )

        }
        Button(
            onClick = { /* TODO: Xử lý sự kiện khi nút được nhấn */ },
            modifier = Modifier
                .padding(top = 24.dp)
                .width(420.dp)
                .height(63.dp)
                .padding(horizontal = 25.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8FD776)),


            ) {
            Text(text = "Request code via 59",
                fontSize = 16.sp,
                fontStyle = FontStyle.Normal) // Chữ của nút
        }
        Text(text = "By clicking on the \"Confirm Login\" button, " +
                "I agree to the terms of use of the service",
            modifier = Modifier
                .padding(top = 32.dp)
                .width(440.dp)
                .height(54.dp)
                .padding(horizontal = 33.dp),
        )

    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun Step2Preview() {
    Lab2Theme {
        Step2Screen()
    }
}
