package com.example.lab2

fun main(){

}