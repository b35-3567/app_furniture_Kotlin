package com.example.lab2.Demo_Function



fun greet(name:String){
    println("XIn chào bạn:${name}")
}
fun hamTraVe(a:Int, b:Int):Int{
    return a+b;
}
fun hamGiaTriMacDinhThamSo(name:String ="Hải"){
    println("Xin chào bạn ${name}")
}
val mutiply :(Int,Int)->Int={a,b->a*b}
fun main(){
  greet("sanh");
  println("ví dụ hàm trả về:");
  println(hamTraVe(5,6));
    println("ví dụ hàm giá trị mặc định tham số");
    println(hamGiaTriMacDinhThamSo());
    println(hamGiaTriMacDinhThamSo("Vũ"));
    println("ví dụ  Hàm Lambda");
    val result= mutiply(4,5)
    println("kết quả phép nhân của số 4 và 5 là:${result}")
}