package com.example.lab2

fun main(){
 do {
     print("nhập vào số a:");
     var a= readln().toInt();
     println("chữ số đầu tiên của số a");
     var numberString=a.toString();
     println("vị trí thứ đầu tiên:"+numberString[0]);
     if(a%2==0){
         println("a là số chẵn");
     }else{
         println("a là số lẻ");
     }
     var giamdan=true;
     for (i in 0 until numberString.length-1){
         if(numberString[i] < numberString[i+1]){
             giamdan=false;
         }
     }
     if(giamdan){
         println("các chữ số giảm dần");
     }else{
         println("không phải các chữ số giảm dần");
     }
 }while (a>0)
}