package com.example.lab2.ThiNay

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.lab2.R
import com.example.lab2.thi.HomeThiScreen
import com.example.lab2.thi.ProductTech
import com.example.lab2.ui.theme.Lab2Theme

class danhMucActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            Lab2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    val navController = rememberNavController()
                    danhMucScreen(navController)
                }
            }
        }
    }
}
data class DanhMuc(val Name:String)
data class itemPlant(val Ten:String,val Type:String,val Price:String,val Hinh:Int)
@Composable
fun danhMucScreen(navController: NavController){
    var data1 by remember {
    mutableStateOf(
        listOf(
            DanhMuc(Name= "Tât cả"),
            DanhMuc(Name= "Hàng Mới Về"),
            DanhMuc(Name= "Ưa sáng"),
            DanhMuc(Name= "Ưa bóng"),
        )

    )
}
    var data2 by remember {
        mutableStateOf(
            listOf(
                itemPlant(Ten= "Spier Plant", Type = "Ưa bóng", Price = "250000", Hinh = R.drawable.plant_1),
                itemPlant(Ten= "Black Love Anthurium", Type = "Ưa sáng", Price = "250000", Hinh = R.drawable.plant_2),
                itemPlant(Ten= "Spier Plant", Type = "Ưa sáng", Price = "250000", Hinh = R.drawable.plant_3),
                itemPlant(Ten= "Song of India", Type = "Ưa bóng", Price = "250000", Hinh = R.drawable.plant_4),
                itemPlant(Ten= "Spier Plant", Type = "Ưa tối", Price = "250000", Hinh = R.drawable.plant_5),
                itemPlant(Ten= "Spier Plant", Type = "Ưa sáng", Price = "250000", Hinh = R.drawable.plant_6),

            )

        )
    }

    Column {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .padding(end = 25.dp)
                .fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .padding(start = 20.dp)
                    .size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBackIosNew,
                    contentDescription = "Search Icon"
                )
            }
            Text(text = "Category")
            Box(
                modifier = Modifier
                    .padding(start = 20.dp)
                    .size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = "Search Icon",
                )
                Canvas(
                    modifier = Modifier
                        .size(9.dp)
                        .align(Alignment.TopEnd)
                        .padding(top = 2.dp, end = 2.dp)
                ) { drawCircle(Color.Red) }
            }
        }
        ////////////////////////////////////////
        Spacer(modifier = Modifier.height(16.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(data1) { danhMuc ->
                val backgroundColor = if (danhMuc.Name == "Tât cả") Color(0xFF009245) else Color.Transparent
                val textColor = if (danhMuc.Name == "Tât cả") Color.White else Color.Gray

                Box(
                    modifier = Modifier
                        .background(backgroundColor, shape = MaterialTheme.shapes.small)
                        .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.small) // Add border to non-selected items
                        .padding(horizontal =16.dp, vertical = 8.dp)
                ) {
                    Text(text = danhMuc.Name, color = textColor,
                        fontSize = 14.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(data2) { plant ->
                Column(
                    //horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .background(Color(0xFFF6F6F6), shape = MaterialTheme.shapes.small)
                        .padding(4.dp)
                        .clickable{navController.navigate("home1")}
                ) {
                    Image(
                        painter = painterResource(id = plant.Hinh),
                        contentDescription = plant.Ten,
                        modifier = Modifier.width(155.dp)
                            .height(134.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = plant.Ten, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(text = plant.Type)
                    Text(text = plant.Price, color = Color(0xFF007537))
                }
            }
        }
//////////////////
    }//coloumn tổng
}
@RequiresApi(Build.VERSION_CODES.R)
@Preview(showSystemUi = true, showBackground = true)
@Composable
fun danhMucPreview() {
    Lab2Theme {
        val navController = rememberNavController()
        danhMucScreen(navController)
    }
}