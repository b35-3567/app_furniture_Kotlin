package com.example.lab2.Demo_Function

fun main(){
    val fruit= arrayListOf("danh","lan","Huệ ","cúc");
    fruit.forEach{
        note->println(note)
    }
}