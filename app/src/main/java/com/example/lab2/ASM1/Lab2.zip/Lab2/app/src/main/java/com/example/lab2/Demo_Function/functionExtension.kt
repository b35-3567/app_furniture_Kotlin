package com.example.lab2.Demo_Function

fun String.addExclamation():String{
    return this + "!"
}
fun main(){
    println("Hàm mở rộng:")
    val message="Hello";
    println(message.addExclamation());

}