package com.example.lab2

fun main() {
    println(10%2)
    print("Nhập số n: ")
    val n = readln().toInt()

    var original = n
    var soChuyenDoi = 0
    var dem = n


    while (dem > 0) {
        val number = dem % 10;

        soChuyenDoi = soChuyenDoi * 10 + number

        dem /= 10
    }


    if (original == soChuyenDoi) {
        println("Số $n là số đối xứng")
    } else {
        println("Số $n không phải số đối xứng")
    }
}

