package com.example.lab2.Demo_Function

fun operateOnNumbers(a:Int,b:Int,operation: (Int,Int)->Int):Int{
    return operation(a,b)
}
fun main(){
    val sum= operateOnNumbers(4,5){x,y->x+y}
    println("tổng của hai số ${sum}");
    val product = operateOnNumbers(5,6){x,y->x*y}
    println("thương của hai số ${product}");
}