package com.example.lab2.Demo_Function

class Caculator{
    fun subtract(a:Int,b:Int):Int{
        return a-b
    }
}
fun main(){
val caculator=Caculator();
    val sub=caculator.subtract(10,5);
    println("Kết quả của phép trừ ${sub}");
}