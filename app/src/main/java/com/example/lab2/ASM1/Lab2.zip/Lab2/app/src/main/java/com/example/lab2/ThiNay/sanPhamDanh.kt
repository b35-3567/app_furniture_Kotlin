package com.example.lab2.ThiNay

import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.lab2.R
import com.example.lab2.ui.theme.Lab2Theme

class sanPhamDanhActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            Lab2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    val navController = rememberNavController()
                    sanPhamDanhScreen(navController)
                }
            }
        }
    }
}
@Composable
fun sanPhamDanhScreen(navController: NavController){
    var quantity by remember { mutableStateOf(0) }
    var thongBao by remember { mutableStateOf("") }
    val context1= LocalContext.current;


    fun chonMua() {
        if(quantity==0){
            thongBao="số lượng đang là 0"
        }else {
            thongBao = "Thêm giỏ hàng thành công!"
        }
      //  Toast.makeText(context1, "Thêm vào giỏ hàng thành công", Toast.LENGTH_LONG).show()
  }


    Column {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .padding(end = 25.dp)
                .fillMaxWidth()
                .height(55.dp)
        ) {
            Box(
                modifier = Modifier
                    .padding(start = 20.dp)
                    .size(24.dp)
                   // .clickable{navController.popBackStack()}
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBackIosNew,
                    contentDescription = "Search Icon",

                )
            }
            Text(text = "Spider Plant")
            Box(
                modifier = Modifier
                    .padding(start = 20.dp)
                    .size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = "Search Icon",
                )
                Canvas(
                    modifier = Modifier
                        .size(9.dp)
                        .align(Alignment.TopEnd)
                        .padding(top = 2.dp, end = 2.dp)
                ) { drawCircle(Color.Red) }
            }
        }
        ////////////////////////////////////////
        Image(
            painter = painterResource(id = R.drawable.plant_4),
            contentDescription =" plant.Ten",
            modifier = Modifier
                .padding(start = 25.dp)
                .width(337.dp)
                .height(270.dp)
                .background(color = Color(0xFFFFF))
        )
       Column(
           modifier = Modifier
               .padding(start = 48.dp)
       ) {
          Row (
              modifier = Modifier
                  .padding(top=23.dp)
          ){
              Box( modifier = Modifier
                  .width(80.dp)
                  .height(30.dp)
                  .background(color = Color(0xFF009245))
              ) {
                  Text(text = "Cây trồng", modifier = Modifier
                      .align(alignment = Alignment.CenterStart),
                      color = Color.White
                  )
              }
              Box( modifier = Modifier
                  .padding(start = 10.dp)
                  .width(80.dp)
                  .height(30.dp)
                  .background(color = Color(0xFF009245))
              ) {
                  Text(text = "Ưa bóng", modifier = Modifier
                      .align(alignment = Alignment.CenterStart),
                      color = Color.White
                  )
              }
          }
           //////////////////////////////////
           Text(text = "250.000", modifier = Modifier
               .padding(top=25.dp),
               color = Color(0xFF007537),
               fontWeight = FontWeight(500),
               fontSize = 24.sp,

           )
           Text(text = "Chi tiết sản phẩm", modifier = Modifier
               .padding(top=30.dp)
           )
           // Divider line
           Divider(
               color = Color.Black,
               thickness = 1.dp,
               modifier = Modifier
                   .width(279.dp)

           )
           Row(
               horizontalArrangement = Arrangement.spacedBy(185.dp),
               modifier = Modifier
                   .padding(top = 25.dp)
                   .fillMaxWidth()
           ){
               Text(text = "Kích cỡ")
               Text(text = "nhỏ")
           }
           Divider(
               color = Color.Gray,
               thickness = 1.dp,
               modifier = Modifier
                   .width(279.dp)

           )
           ///////
           Row(
               horizontalArrangement = Arrangement.SpaceBetween,
               modifier = Modifier
                   .padding(top = 25.dp)
                   .width(279.dp)
           ){
               Text(text = "Xuất xứ")
               Text(text = "Chaun Phi")
           }
           Divider(
               color = Color.Gray,
               thickness = 1.dp,
               modifier = Modifier
                   .width(279.dp)
           )

           //////
           Row(
               horizontalArrangement = Arrangement.SpaceBetween,
               modifier = Modifier
                   .padding(top = 25.dp)
                   .width(279.dp)
           ){
               Text(text = "Đã chọn 0 sản phẩm")
               Text(text = "Tạm tính")
           }
           Row(
               horizontalArrangement = Arrangement.SpaceBetween,
               modifier = Modifier
                   .padding(top = 30.dp)
                   .width(279.dp)
           ) {
               Row(
                   modifier = Modifier
                       .padding(start = 0.dp)
               ) {
                   Box(
                       modifier = Modifier
                           .size(30.dp)
                           .clip(
                               shape = RoundedCornerShape(
                                   topStart = 5.dp,
                                   topEnd = 5.dp,
                                   bottomEnd = 5.dp,
                                   bottomStart = 5.dp
                               )
                           )
                           .clickable { if (quantity > 0) quantity-- }
                           .border(2.dp, Color.Black, RoundedCornerShape(5))
                           .background(color = Color.Transparent),
                       contentAlignment = Alignment.Center, // Canh giữa cả theo chiều ngang và chiều dọc,

                   ) {
                       Text(
                           text = "-",
                           fontSize = 17.sp,
                           fontWeight = FontWeight.Bold,
                           fontStyle = FontStyle.Normal,

                           )
                   }
                   Spacer(modifier = Modifier.width(8.dp))
                   //////////////////////////////////////////////////////////////
                   Box(
                       modifier = Modifier
                           .size(30.dp)
                           .clip(
                               shape = RoundedCornerShape(
                                   topStart = 5.dp,
                                   topEnd = 5.dp,
                                   bottomEnd = 5.dp,
                                   bottomStart = 5.dp
                               )
                           )
                           //background: #F0F0F0;
                           .background(color = Color.White),
                       contentAlignment = Alignment.Center, // Canh giữa cả theo chiều ngang và chiều dọc,

                   ) {
                       Text(
                           text = "${quantity}",
                           fontSize = 17.sp,
                           fontWeight = FontWeight.Bold,
                           fontStyle = FontStyle.Normal
                       )
                   }
                   Spacer(modifier = Modifier.width(8.dp))
                   ///////////////////////////////////////////////////////////
                   Box(
                       modifier = Modifier
                           .size(30.dp)
                           .clip(
                               shape = RoundedCornerShape(
                                   topStart = 5.dp,
                                   topEnd = 5.dp,
                                   bottomEnd = 5.dp,
                                   bottomStart = 5.dp
                               )
                           )
                           .clickable { quantity++ }
                           .border(2.dp, Color.Black, RoundedCornerShape(5))
                           .background(color = Color.Transparent),
                       contentAlignment = Alignment.Center, // Canh giữa cả theo chiều ngang và chiều dọc,

                   ) {
                       Text(
                           text = "+",
                           fontSize = 17.sp,
                           fontWeight = FontWeight.Bold,
                           fontStyle = FontStyle.Normal
                       )
                   }




               }//
               Text(
                   text ="${quantity*250000}", modifier = Modifier
                       .padding(start = 53.dp, top = 2.dp),
                   color = Color.Black, fontSize = 24.sp
               )
           }
       }
        Button(onClick = {chonMua()},
            modifier = Modifier
                .padding(top = 64.dp, start = 0.dp)
                .width(325.dp)
                .align(Alignment.CenterHorizontally)
                .height(50.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (quantity == 0) Color.Gray else Color(0xFF007537),
                contentColor = Color.White
            )

        ) {
            Text(text = "Chọn Mua")
        }
        Text(text = "${thongBao}")
    }
}


@RequiresApi(Build.VERSION_CODES.R)
@Preview(showSystemUi = true, showBackground = true)
@Composable
fun sanPhamDanhPreview() {
    Lab2Theme {
        val navController = rememberNavController()
       sanPhamDanhScreen(navController)
    }
}