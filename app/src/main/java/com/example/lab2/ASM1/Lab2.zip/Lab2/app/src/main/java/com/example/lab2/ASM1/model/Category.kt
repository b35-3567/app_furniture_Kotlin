package com.example.lab2.ASM1.model

data class Category(
    val _id: String,
    val CategoryID: Int,
    val CategoryName: String,
    val __v: Int
)